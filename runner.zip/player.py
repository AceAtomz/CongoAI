class Player:

    def __init__(self, program):
        self.program = program
        self._position = None
        self.moves = list()

    def init(self):
        self.program.send(['newgame'])

    def set_position(self, fen):
        self.program.send(['position {}'.format(fen)])
        self._position = fen

    def request_move(self, timeout):
        out = self.program.communicate(['go {}'.format(timeout)], timeout=timeout)
        return out.strip()

    def tell_move(self, move):
        self.program.send(['moves {}'.format(move)])

    def get_valid_moves(self):
        out = self.program.communicate(['moves', self._position], timeout=1)
        return out.strip().split(' ')

    def close(self):
        self.program.close()
