import asyncio
import subprocess
import threading
import time


async def run_command(program, lines, timeout=None):
    while True:
        line = await asyncio.wait_for(program.send_receive(lines), timeout)
        return line
    return None


class Program:

    def __init__(self, command, event_loop):
        self.process = subprocess.Popen(command, stdin=subprocess.PIPE,
                                        stdout=subprocess.PIPE,
                                        stderr=subprocess.PIPE)
        self._event_loop = event_loop

    def close(self):
        self.process.terminate()

    def to_bytes(self, lines):
        return ('\n'.join(lines).strip() + '\n').encode('utf-8')

    def send(self, lines):
        self.process.stdin.write(self.to_bytes(lines))
        # self.process.stdin.flush()

    async def _send_receive(self, lines):
        self.process.stdin.write(self.to_bytes(lines))
        self.process.stdin.flush()
        return self.process.stdout.readline()

    async def send_receive(self, lines, timeout=None):
        while True:
            try:
                line = await asyncio.wait_for(self._send_receive(lines), timeout)
                return line
            except TimeoutError:
                return None

    def communicate(self, lines, timeout=None):
        out = self._event_loop.run_until_complete(self.send_receive(lines, timeout=timeout))
        if out is not None:
            out = out.decode("utf-8").strip()
        return out




if __name__ == '__main__':
    loop = asyncio.get_event_loop()
    moderator = Program('./checker', loop)
    out = moderator.communicate(['moves', '1z5/pPp1lP1/5ep/4P1e/4L1p/2p2pP/7 w 12'], timeout=1)
    print(out)