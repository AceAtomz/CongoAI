import asyncio

from moderator import Moderator
from player import Player
from program import Program

if __name__ == '__main__':

    loop = asyncio.get_event_loop()
    init_pos = '2ele1z/ppppppp/7/7/7/PPPPPPP/2ELE1Z w 0'
    moderator = Moderator(Program('./checker', loop), init_pos)
    white = Player(Program('./congo', loop))
    black = Player(Program('./congo', loop))

    time_limit = 5
    to_play = 1
    white.init()
    black.init()
    white.set_position(init_pos)
    black.set_position(init_pos)
    moves = list()
    while len(moderator.moves) < 100 and moderator.is_game_over() == 0:
        if to_play == 1:
            player = white
            other = black
        else:
            player = black
            other = white
        move = player.request_move(time_limit)
        if move == 'timeout':
            moves.append(move)
            break
        # check valid
        if move not in moderator.get_valid_moves():
            moves.append(move + ' (invalid)')
            break
        moderator.execute_move(move)
        other.tell_move(move)
        if moderator.is_game_over() != 0:
            moves.append(moderator.is_game_over())
            break
        to_play *= -1

    print(moves)
    moderator.close()
    black.close()
    white.close()
    loop.close()
