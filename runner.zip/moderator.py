class Moderator:

    def __init__(self, program, position):
        self.program = program
        self._position = position
        self.moves = list()

    def get_valid_moves(self):
        out = self.program.communicate(['moves', self._position], timeout=1)
        return out.strip().split(' ')

    def execute_move(self, move):
        self.moves.append(move)
        self._position = self.program.communicate(['next', self._position, move], timeout=1)
        return self._position

    def is_game_over(self):

        if 'l' in self._position and 'L' in self._position:
            return 0  # continue
        if 'l' not in self._position:
            return +1
        return -1

    def close(self):
        self.program.close()
